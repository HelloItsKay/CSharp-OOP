﻿namespace Vehicles
{
    public abstract class Vehicle
    {
        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelConsumption = fuelConsumption;
            FuelQuantity = fuelQuantity;
        }

         public double FuelQuantity { get;protected set; }
        public virtual double FuelConsumption { get; }
       

        public bool CanDrive(double distance)
        {
            bool canDrive = FuelQuantity - FuelConsumption * distance >= 0;
            if (!canDrive)
            {
                return false;
            }

            FuelQuantity -= FuelConsumption * distance;
            return true;
        }

        public virtual void Refuel(double amount)
        {
            FuelQuantity += amount;
        }
    }
}
