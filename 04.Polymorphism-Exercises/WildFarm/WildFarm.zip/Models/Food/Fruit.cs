﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    class Fruit:Vegetable
    {
        public Fruit(int quantity) : base(quantity)
        {
        }
    }
}
