﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tele.Interfaces
{
    public interface ICallable
    {
        public string Call(string phoneNumber);
    }
}
