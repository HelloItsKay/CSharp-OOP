﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable>indentifiables=new List<IIdentifiable>();
            while (true)
            {
                string  line= Console.ReadLine();
                if (line == "End")break;
                string[] parts = line.Split();
                if (parts.Length==3)
                {
                    string name=parts[0];
                    int age = Convert.ToInt32(parts[1]);
                    string id = parts[2];
                    indentifiables.Add(new Citizen(name,age,id));

                }
                else
                {
                    string model = parts[1];
                    string id = parts[0];
                    indentifiables.Add(new Robot(model,id));
                }
            }

            string filterId = Console.ReadLine();
            List<IIdentifiable>filtered = indentifiables.Where(i => i.Id.EndsWith(filterId)).ToList();
            foreach (var item in filtered)
            {
                Console.WriteLine(item.Id);   
            }

        }
    }
}
