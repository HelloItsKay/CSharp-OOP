﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IBrowse
    {
        public void Browsing(string url);
    }
}
