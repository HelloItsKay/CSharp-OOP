﻿namespace Bakery.Utilities.Enums
{
    public enum TableType
    {
        InsideTable = 1,
        OutsideTable = 2
    }
}