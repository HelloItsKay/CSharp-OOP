﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CarRacing.Models.Racers.Contracts;
using CarRacing.Repositories.Contracts;

namespace CarRacing.Repositories
{
    class RacerRepository:IRepository<IRacer>
    {
        private readonly List<IRacer> racers;

        public RacerRepository()
        {
            racers=new List<IRacer>();
        }

        public IReadOnlyCollection<IRacer> Models => racers.ToList();
        public void Add(IRacer model)
        {
           racers.Add(model);
        }

        public bool Remove(IRacer model)
        {
            return racers.Remove(model);
        }

        public IRacer FindBy(string property)
        {
            return racers.FirstOrDefault(x =>x.Username == property);
        }
    }
}
