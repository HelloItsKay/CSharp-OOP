﻿using System;
using System.Collections.Generic;
using System.Text;
using WarCroft.Entities.Items;

namespace WarCroft.Entities.Inventory
{
    public class Backpack : Bag
    {
        public Backpack() : base(100)
        {
            
        }
    }
}
