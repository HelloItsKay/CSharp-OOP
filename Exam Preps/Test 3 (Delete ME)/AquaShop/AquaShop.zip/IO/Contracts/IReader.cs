﻿namespace AquaShop.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}